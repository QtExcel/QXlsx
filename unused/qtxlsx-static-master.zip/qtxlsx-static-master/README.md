# qtxlsx-static
## QtXlsx static library project
* see version.txt 
* .Xlsx file wirter for Qt5
* original source code from Debao Zhang
* Copyright (C) 2013-2014 Debao Zhang <hello@debao.me>
* http://qtxlsx.debao.me/
* MIT License
